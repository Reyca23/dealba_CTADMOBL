package com.example.dealba_advmobprog

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
